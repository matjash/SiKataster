SiKataster je orodje za dostop do podatkov o parcelah v Katastru nepremičnin Geodetske uprave Republike Slovenije (GURS).
Vtičnik je zasnovan na način, da v metapodatke slojev, ki jih ustvari, zapiše informacije o viru in datumu prevzema podatkov.
Podatke in spletni servis zagotavlja GURS.
